<?php

namespace Butschster\Head\Contracts\Packages\Entities;

use Butschster\Head\Contracts\Packages\PackageInterface;
use Illuminate\Contracts\Support\Htmlable;

interface TwitterCardPackageInterface extends PackageInterface
{

}